ATH9KFixup Changelog
====================

#### v1.1.0
- Added High Sierra compatibility

#### v1.0.5
- Cosmetic changes

#### v1.0.4
- Lilu.kext updated to 1.1.7

#### v1.0.3
- Cosmetic changes

#### v1.0.2
- Lilu.kext updated to 1.1.6

#### v1.0.1
- Cosmetic changes

#### v1.0.0
- Initial release
